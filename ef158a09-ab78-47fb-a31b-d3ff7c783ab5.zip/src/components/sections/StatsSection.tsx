import React, { useEffect, useState } from 'react';
import { Users2Icon, GamepadIcon, EyeIcon } from 'lucide-react';
import { useInView } from 'react-intersection-observer';
interface StatCardProps {
  icon: React.ReactNode;
  value: number;
  label: string;
  delay?: number;
}
const StatCard = ({
  icon,
  value,
  label,
  delay = 0
}: StatCardProps) => {
  const [count, setCount] = useState(0);
  const {
    ref,
    inView
  } = useInView({
    threshold: 0.3,
    triggerOnce: true
  });
  useEffect(() => {
    if (inView) {
      const duration = 2000; // Animation duration in milliseconds
      const steps = 60; // Number of steps in the animation
      const stepValue = value / steps;
      let currentStep = 0;
      setTimeout(() => {
        const timer = setInterval(() => {
          currentStep++;
          setCount(Math.min(Math.floor(stepValue * currentStep), value));
          if (currentStep >= steps) clearInterval(timer);
        }, duration / steps);
        return () => clearInterval(timer);
      }, delay);
    }
  }, [inView, value, delay]);
  return <div ref={ref} className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 flex flex-col items-center justify-center transition-all duration-300 hover:transform hover:scale-105 hover:bg-white/10">
      <div className="text-purple-400 mb-4">{icon}</div>
      <div className="text-4xl md:text-5xl font-bold text-white mb-2">
        {count.toLocaleString()}
      </div>
      <div className="text-gray-400 text-sm uppercase tracking-wider">
        {label}
      </div>
    </div>;
};
export const StatsSection = () => {
  return <div className="bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <StatCard icon={<GamepadIcon size={32} />} value={96} label="Total Games" delay={0} />
          <StatCard icon={<EyeIcon size={32} />} value={51807} label="Happy Users" delay={200} />
          <StatCard icon={<Users2Icon size={32} />} value={5} label="Team Members" delay={400} />
        </div>
      </div>
    </div>;
};