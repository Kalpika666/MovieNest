import React, { useState } from 'react';
import { GamepadIcon, SparklesIcon, TrendingUpIcon } from 'lucide-react';
import { GameCard } from '../ui/GameCard';
const categories = ['All', 'Action', 'Adventure', 'Puzzle', 'Racing', 'Sports', 'Strategy'];
const gamesData = [{
  id: 1,
  title: 'Space Explorer',
  description: 'Navigate through space, collect resources, and fight alien enemies in this exciting adventure game.',
  image: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80',
  category: 'Adventure',
  players: 25,
  playTime: '15 min'
}, {
  id: 2,
  title: 'Puzzle Master',
  description: 'Challenge your brain with increasingly difficult puzzles. Perfect for casual gaming sessions.',
  image: 'https://images.unsplash.com/photo-1611996575749-79a3a250f948?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80',
  category: 'Puzzle',
  players: 42,
  playTime: '10 min'
}, {
  id: 3,
  title: 'Racing Legends',
  description: 'Race against time and opponents on spectacular tracks around the world.',
  image: 'https://images.unsplash.com/photo-1547949003-9792a18a2601?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80',
  category: 'Racing',
  players: 18,
  playTime: '20 min'
}, {
  id: 4,
  title: 'Zombie Survival',
  description: 'Survive in a post-apocalyptic world filled with zombies. Gather resources and build defenses.',
  image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80',
  category: 'Action',
  players: 35,
  playTime: '30 min'
}, {
  id: 5,
  title: 'Medieval Strategy',
  description: 'Build your kingdom, train armies, and conquer territories in this epic strategy game.',
  image: 'https://images.unsplash.com/photo-1590336162350-0f09a85831e2?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80',
  category: 'Strategy',
  players: 15,
  playTime: '45 min'
}, {
  id: 6,
  title: 'Soccer Stars',
  description: 'Lead your team to victory in this fast-paced soccer simulation game.',
  image: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80',
  category: 'Sports',
  players: 28,
  playTime: '12 min'
}];
export const GamesSection = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const filteredGames = selectedCategory === 'All' ? gamesData : gamesData.filter(game => game.category === selectedCategory);
  return <>
      <section id="categories" className="mb-16">
        <div className="flex flex-wrap gap-2">
          {categories.map(category => <button key={category} onClick={() => setSelectedCategory(category)} className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                ${selectedCategory === category ? 'bg-purple-600 dark:bg-purple-500 text-white' : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 hover:bg-purple-50 dark:hover:bg-gray-700'}`}>
              {category}
            </button>)}
        </div>
      </section>
      <section id="featured" className="mb-16 scroll-mt-16">
        <div className="flex items-center space-x-2 mb-8">
          <SparklesIcon size={28} className="text-purple-600 dark:text-purple-400" />
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">
            Featured Games
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGames.slice(0, 3).map(game => <GameCard key={game.id} {...game} />)}
        </div>
      </section>
      <section id="popular" className="scroll-mt-16">
        <div className="flex items-center space-x-2 mb-8">
          <TrendingUpIcon size={28} className="text-purple-600 dark:text-purple-400" />
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white">
            Popular Games
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGames.slice(3).map(game => <GameCard key={game.id} {...game} />)}
        </div>
      </section>
    </>;
};