import React, { useEffect, useState } from 'react';
import { ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
const slides = [{
  id: 1,
  title: 'Featured Games',
  description: 'Play the hottest HTML5 games right in your browser',
  image: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&h=600&q=80',
  color: 'from-purple-600 to-blue-600',
  link: '#featured'
}, {
  id: 2,
  title: 'New Releases',
  description: 'Check out our latest game additions',
  image: 'https://images.unsplash.com/photo-1614728263952-84ea256f9679?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&h=600&q=80',
  color: 'from-blue-600 to-teal-500',
  link: '#new'
}, {
  id: 3,
  title: 'Popular Games',
  description: 'Discover what other players are enjoying',
  image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&h=600&q=80',
  color: 'from-teal-500 to-purple-500',
  link: '#popular'
}];
export const HeroBanner = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const nextSlide = () => {
    setCurrentSlide(prev => prev === slides.length - 1 ? 0 : prev + 1);
  };
  const prevSlide = () => {
    setCurrentSlide(prev => prev === 0 ? slides.length - 1 : prev - 1);
  };
  useEffect(() => {
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, []);
  return <div className="relative h-[500px] w-full overflow-hidden">
      {slides.map((slide, index) => <div key={slide.id} className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <div className="absolute inset-0 bg-black/50 z-10"></div>
          <img src={slide.image} alt={slide.title} className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 z-20 flex items-center justify-center">
            <div className="text-center text-white px-4 max-w-3xl">
              <h1 className={`text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r ${slide.color} text-transparent bg-clip-text`}>
                {slide.title}
              </h1>
              <p className="text-lg md:text-xl mb-8">{slide.description}</p>
              <a href={slide.link} className={`inline-block bg-gradient-to-r ${slide.color} text-white font-medium rounded-full px-8 py-3 hover:opacity-90 transition-opacity`}>
                Explore Now
              </a>
            </div>
          </div>
        </div>)}
      <button onClick={prevSlide} className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 rounded-full p-2 backdrop-blur-sm transition-all">
        <ChevronLeftIcon size={24} className="text-white" />
      </button>
      <button onClick={nextSlide} className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 rounded-full p-2 backdrop-blur-sm transition-all">
        <ChevronRightIcon size={24} className="text-white" />
      </button>
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex space-x-2">
        {slides.map((_, index) => <button key={index} onClick={() => setCurrentSlide(index)} className={`w-3 h-3 rounded-full transition-all ${index === currentSlide ? 'bg-white scale-125' : 'bg-white/50'}`}></button>)}
      </div>
    </div>;
};