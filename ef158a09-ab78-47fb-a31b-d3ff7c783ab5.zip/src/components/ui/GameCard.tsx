import React from 'react';
import { PlayIcon, UsersIcon, ClockIcon } from 'lucide-react';
interface GameCardProps {
  title: string;
  description: string;
  image: string;
  category: string;
  players: number;
  playTime: string;
}
export const GameCard = ({
  title,
  description,
  image,
  category,
  players,
  playTime
}: GameCardProps) => {
  return <div className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 h-full flex flex-col">
      <div className="relative overflow-hidden group">
        <img src={image} alt={title} className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-105" />
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <button className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm text-purple-600 dark:text-purple-400 font-medium rounded-full px-6 py-2 flex items-center space-x-2 hover:bg-white dark:hover:bg-gray-800 transition-colors">
            <PlayIcon size={18} />
            <span>Play Now</span>
          </button>
        </div>
        <div className="absolute top-3 left-3">
          <span className="bg-purple-600 dark:bg-purple-500 text-white text-xs font-medium px-2.5 py-1 rounded-full">
            {category}
          </span>
        </div>
      </div>
      <div className="p-5 flex-grow flex flex-col">
        <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-2">
          {title}
        </h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 flex-grow">
          {description}
        </p>
        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
          <div className="flex items-center space-x-1">
            <UsersIcon size={16} />
            <span>{players}k plays</span>
          </div>
          <div className="flex items-center space-x-1">
            <ClockIcon size={16} />
            <span>{playTime}</span>
          </div>
        </div>
      </div>
    </div>;
};